from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get('https://demoqa.com/books')
driver.find_element(By.LINK_TEXT,'Learning Python').click()
driver.find_element(By.ID,'addNewRecordButton').click()
time.sleep(2)
print('Add to Cart Test Completed')
driver.quit()