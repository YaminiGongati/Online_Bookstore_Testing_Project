from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get('https://demoqa.com/login')
driver.find_element(By.ID, 'userName').send_keys('testuser')
driver.find_element(By.ID, 'password').send_keys('test123')
driver.find_element(By.ID, 'login').click()
time.sleep(2)
if 'Welcome' in driver.page_source:
    print('Login Test Passed')
driver.quit()