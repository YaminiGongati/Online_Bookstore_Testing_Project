# Online Bookstore Testing Project
This project includes Manual Testing, Automation Testing with Python Selenium, Database Testing with SQL, and sample Jira bug report.